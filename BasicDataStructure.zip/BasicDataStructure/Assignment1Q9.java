import java.util.*;
class Student {
    private int subjectA,subjectB,subjectC;

    //3public int studentsTotalMarksInAllSubjects(Student[] students) {}
    
    //4public double studentsAverageMarksInAllSubjects(Student[] students) {}
    
    public int[] subjectWiseMarks(Student[] students,String subjectName)
    public int subjectTotalByStudents(int[] marks)
   	
    //5public int subjectATotalByStudents(int[] marks) {}
    //6public double subjectAAverageByStudents(int[] marks) {}
    //7public int subjectBTotalByStudents(int[] marks) {}
    //8public double subjectBAverageByStudents(int[] marks) {}
    //9public int subjectCTotalByStudents(int[] marks) {}
    //10public double subjectCAverageByStudents(int[] marks) {}

}

public class Assignment1Q9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student marks = new Students();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the how many students:");
		int a=sc.nextInt();
		int subjs[]=new int[3];
		for(int i=0;i<a;i++)
		{
			for(int j=0;j<3;j++)
			{
				subjs[j]=sc.nextInt();
			}
			
			System.out.println(marks.studentsTotalMarksInAllSubjects();
		}
	}

}
