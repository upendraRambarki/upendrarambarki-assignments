
class ArmstrongNumBetweenRange {
	
public int[] armstrongNumberinRange(int min,int max)
    {
		int[] arr = new int[4];
		int i;
		int k=0;
    	for(i=min;i<=max;i++)
    	{
    		int a1=i;
    		int c=0;
    		int r;
    		while(a1>0)
    		{
    			r=a1%10;
    			c=c+(r*r*r);
    			a1=a1/10;
    		}
    		
    		if(c==i)
    		{
    				arr[k]=i;
    				k++;    			
    		}
    		
    	}  
    	return arr;
    }
}
public class Assignment1Q2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int min=100;int max=999;
		ArmstrongNumBetweenRange obj=new ArmstrongNumBetweenRange();
		int[] arr= obj.armstrongNumberinRange(min,max);
		for(int j=0;j<arr.length;j++)
		{
			System.out.print(arr[j]+" ");
		}		
	}
		
}
