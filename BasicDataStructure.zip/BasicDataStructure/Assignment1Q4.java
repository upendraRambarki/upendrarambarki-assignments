import java.util.*;
class ResultDeclaration{
    public String declareResults( double subject1Marks, double subject2Marks, double subject3Marks) {
    	double s1,s2,s3;
    	s1=subject1Marks;
    	s2=subject2Marks;
    	s3=subject3Marks;
    	String s="";
    	if(s1>60&&s2>60&&s3>60)
    	{
    		s=s+"passed";
    	}
    	else if((s1>60&&s2>60)||(s2>60&&s3>60)||(s3>60&&s1>60))
    	{
    		s=s+"promoted";
    	}
    	else if((s1>60&&s2<60&&s3<60)||(s1<60&&s2>60&&s3<60)||(s1<60&&s2<60&&s3>60)||(s1<60&&s2<60&23<=60))
    	{
    		s=s+"failed";
    	}
    	return s;
    	
    }
}
public class Assignment1Q4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ResultDeclaration results = new ResultDeclaration();
		Scanner sc= new Scanner(System.in);
		System.out.print("enter how many test you want to run:");
		int a=sc.nextInt();
		for(int i=0;i<a;i++)
		{
			double subj1=sc.nextDouble();
			double subj2=sc.nextDouble();
			double subj3=sc.nextDouble();
			System.out.println(results.declareResults(subj1,subj2,subj3));
		}		
	}
}
