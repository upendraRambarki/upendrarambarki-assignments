class SiCi {
	
    public double simpleInterest(double principalAmount,int time,double interestRate){
    	double p;
    	p=principalAmount;
    	int t;
    	t=time;
    	double i;
    	i=interestRate;
    	double simpleinterest;
    	simpleinterest=(double)(p*t*i)/100;
    	return simpleinterest;
    	
    }
    
    public double compoundInterest(double principalAmount,int time,double interestRate){
    	double compoundinterest;
    	
    	compoundinterest = (principalAmount * Math.pow(1 + (interestRate),time))-principalAmount;
    	return compoundinterest;
    }
}
public class Assignment1Q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SiCi intrest = new SiCi();
		System.out.println(intrest.simpleInterest(10, 20, 30));
		System.out.println(intrest.compoundInterest(10, 20, 30));

	}

}
