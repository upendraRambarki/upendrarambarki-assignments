import java.util.*;
class ArmstrongOrNot {
    public boolean armstrongCheck(int num)
    {
    	int a1=num;
    	int count=0;
    	while(a1>0)
    	{
    		a1=a1/10;
    		count=count+1;
    	}
    	int a2=num;
    	int arm=0;
    	int a3;
    	while(a2>0)
    	{
    		int b=1;
    		a3=a2%10;
    		for(int i=0;i<count;i++)
    		{
    			b=b*a3;	
    		}
    		arm=arm+b;
    		a2=a2/10;
    	}
    	if(arm==num)
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}	
    }
}

public class Assignment1Q1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean check;
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		ArmstrongOrNot obj = new ArmstrongOrNot();
		check=obj.armstrongCheck(num);
		System.out.println(check);
		}
}

/*
import java.util.*;
class ArmstrongOrNot {
    public boolean armstrongCheck(int num)
    {
    	int a1=num;
    	int count=0;
    	while(a1>0)
    	{
    		a1=a1/10;
    		count=count+1;
    	}
    	int a2=num;
    	int arm=0;
    	int a3;
    	while(a2>0)
    	{
    		int b=1;
    		a3=a2%10;
    		for(int i=0;i<count;i++)
    		{
    			b=b*a3;	
    		}
    		arm=arm+b;
    		a2=a2/10;
    	}
    	if(arm==num)
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
}

public class Assignment1Q2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		ArmstrongOrNot obj = new ArmstrongOrNot();
		System.out.println(obj.armstrongCheck(num));
		}
}
*/









/*int num=371;
int a1=num;
int c1=0;
while(a1>0)
{
	a1=a1/10;
	c1=c1+1;
}
System.out.println(c1);
int a2=num;
int arm=0;
int a3;
while(a2>0)
{
	a3=a2%10;
	int c2=1;
	for(int i=0;i<c1;i++)
	{
		c2=c2*a3;
	}
	arm=arm+c2;
	System.out.println(arm);
	a2=a2/10;
	}
*/