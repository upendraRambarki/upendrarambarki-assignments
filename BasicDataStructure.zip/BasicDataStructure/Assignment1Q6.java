import java.util.*;

class Login{
    String userId = "Ajay",password = "password";
    int n=0;
    public String loginUser(String user, String pass) {
    	if((user.equals(userId)) && (pass.equals(password)))
    	{
    		return "Welcome " + userId;
    	}
    	else {
    		return "false";
    	}
    }

}
public class Assignment1Q6 {
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	Login obj = new Login();
    	String l;
    	while(obj.n<=3)
    	{
    		System.out.println("Enter userId");
    		String user = sc.nextLine();
    		System.out.println("Enter password");
    		String pass = sc.nextLine();
    		l = obj.loginUser(user,pass);
    		if(!(l.equals("false")))
    		{
    			System.out.println(l);
    			break;
    		}
    		else {
    			if(obj.n==0)
    			{
    				System.out.println("You have entered wrong credentials ,please enter the right credentials.");
        			System.out.println("Please re-enter the details.");
        			obj.n++;
    			}
    			else if(obj.n==1)
    			{
    				System.out.println("You have entered wrong credentials ,please enter the right credentials.");
        			System.out.println("Please re-enter the details.");
        			obj.n++;
    			}
    			else if(obj.n==2)
    			{
    				System.out.println("You have entered wrong credentials 3 times");
            		System.out.println("Contact Admin");
            		break;
    			}
    			
    		}
    	}
    }
}

/*import java.util.*;
class Login{
    String userId = "Ajay",password = "password";
    int n=0;	
    public String loginUser(String user, String pass) {
    	if((user==userId)&& (pass==password))
    	{ 
    		return "welcome"+ userId;
    	}
    	else
    	{
    		return "false";
    	}
    }

}
public class AssignmentQ6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter userid:");
		String userId =sc.nextLine();
		System.out.println("Enter password:");
		String password =sc.nextLine();
		Login log = new Login();
		log.loginUser(userId, password));
	}

}*/
