import java.util.*;
class TaxAmount{
    public double calculateTaxAmount(int ctc){
    	double Tax=0.0d;
    	if(ctc>=0 && ctc<=180000)
    	{
    		Tax=0;
    	}
    	else if(ctc>=181001&&ctc<=300000)
    	{
    		Tax=0.1*(ctc);
    	}
    	else if(ctc>=300001&&ctc<=500000)
    	{
    		Tax=0.2*(ctc);
    	}
    	else if(ctc>=500001&&ctc<=1000000)
    	{
    		Tax=0.3*(ctc);
    	}
    	return Tax;
    }
}
public class Assignment1Q5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter income here");
		int income=sc.nextInt();
		TaxAmount tax= new TaxAmount();
		System.out.println("tax should be paid for amount"+" "+income+"is"+tax.calculateTaxAmount(income));
		
	}

}
